class PrinterNotFound(Exception):
    pass
